﻿using BikeAppndRepair.Data;
using BikeAppndRepair.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace MotosikletSatis.Controllers
{
    public class MotosikletController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MotosikletController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Motosiklet
        public async Task<IActionResult> Index()
        {
            var motosikletler = await _context.Motosikletler
                .Include(m => m.Kategori)
                .Include(m => m.Marka)
                .ToListAsync();
            return View(motosikletler);
        }

        // GET: Motosiklet/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var motosiklet = await _context.Motosikletler
                .Include(m => m.Kategori)
                .Include(m => m.Marka)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (motosiklet == null)
            {
                return NotFound();
            }

            return View(motosiklet);
        }

        // GET: Motosiklet/Create
        public IActionResult Create()
        {
            ViewData["KategoriId"] = new SelectList(_context.Kategoriler, "Id", "Ad");
            ViewData["MarkaId"] = new SelectList(_context.Markalar, "Id", "Ad");
            return View();
        }

        // POST: Motosiklet/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Model,KategoriId,MarkaId,Fiyat,ResimYolu")] Motosiklet motosiklet)
        {
            if (ModelState.IsValid)
            {
                _context.Add(motosiklet);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["KategoriId"] = new SelectList(_context.Kategoriler, "Id", "Ad", motosiklet.KategoriId);
            ViewData["MarkaId"] = new SelectList(_context.Markalar, "Id", "Ad", motosiklet.MarkaId);
            return View(motosiklet);
        }

        // GET: Motosiklet/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var motosiklet = await _context.Motosikletler.FindAsync(id);
            if (motosiklet == null)
            {
                return NotFound();
            }
            ViewData["KategoriId"] = new SelectList(_context.Kategoriler, "Id", "Ad", motosiklet.KategoriId);
            ViewData["MarkaId"] = new SelectList(_context.Markalar, "Id", "Ad", motosiklet.MarkaId);
            return View(motosiklet);
        }

        // POST: Motosiklet/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Model,KategoriId,MarkaId,Fiyat,ResimYolu")] Motosiklet motosiklet)
        {
            if (id != motosiklet.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(motosiklet);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MotosikletExists(motosiklet.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["KategoriId"] = new SelectList(_context.Kategoriler, "Id", "Ad", motosiklet.KategoriId);
            ViewData["MarkaId"] = new SelectList(_context.Markalar, "Id", "Ad", motosiklet.MarkaId);
            return View(motosiklet);
        }

        private bool MotosikletExists(int id)
        {
            return _context.Motosikletler.Any(e => e.Id == id);
        }
    }
}
