﻿using System.Collections.Generic;

namespace BikeAppndRepair.Models
{
    public class Motosiklet
    {
        public int Id { get; set; }
        public string Model { get; set; }
        public int KategoriId { get; set; }
        public Kategori Kategori { get; set; }
        public int MarkaId { get; set; }
        public Marka Marka { get; set; }
        public decimal Fiyat { get; set; }
        public string ResimYolu { get; set; }
    }
}
