﻿namespace BikeAppndRepair.Models
{
    public class Kullanıcı
    {
        public int Id { get; set; }
        public string KullaniciAdi { get; set; }
        public string Sifre { get; set; }
    }
}
