﻿using System.Collections.Generic;

namespace BikeAppndRepair.Models
{
    public class Kategori
    {
        public int Id { get; set; }
        public string Ad { get; set; }
        public ICollection<Motosiklet> Motosikletler { get; set; }
    }
}

