﻿namespace BikeAppndRepair.Models
{
    public class SiparisDetay
    {
        public int Id { get; set; }
        public int SiparisId { get; set; }
        public Siparis Siparis { get; set; }
        public int MotosikletId { get; set; }
        public Motosiklet Motosiklet { get; set; }
        public int Adet { get; set; }
    }
}
