﻿using System;
using System.Collections.Generic;

namespace BikeAppndRepair.Models
{
    public class Siparis
    {
        public int Id { get; set; }
        public int KullanıcıId { get; set; }
        public Kullanıcı Kullanıcı { get; set; }
        public DateTime SiparisTarihi { get; set; }
        public ICollection<SiparisDetay> SiparisDetaylar { get; set; }
    }
}
